# proyecto-basico

La idea es tener un proyecto html básico a la mano, que nos sirva de base para explicar herramientas y plugins web.
